export interface BlockAttributes {
	productId: number;
	isDescendentOfQueryLoop: boolean;
	isDescendantOfAllProducts: boolean;
}
