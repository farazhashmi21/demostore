export const singleProductBlockPreview = (
	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 230 100">
		<path
			fill="#E1E3E6"
			d="M76 0h11v6H76zm0 11h88v11H76zm0 16h28v6H76zm0 17h154v28H76zm0 39h22v17H76zm28 0h44v17h-44zM0 0h66v66H0z"
			style={ {
				width: '100%',
			} }
		/>
	</svg>
);
