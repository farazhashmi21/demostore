export interface AddToCartEventDetail {
	// Whether cart data in the data store should be preserved.
	preserveCartData?: boolean;
}
