export interface StoreNoticesState {
	containers: string[];
}

export const defaultStoreNoticesState: StoreNoticesState = {
	containers: [],
};
