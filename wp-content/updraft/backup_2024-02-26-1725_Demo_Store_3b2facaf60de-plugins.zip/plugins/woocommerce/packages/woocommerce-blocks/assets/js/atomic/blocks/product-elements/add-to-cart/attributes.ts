export const blockAttributes = {
	showFormElements: {
		type: 'boolean',
		default: false,
	},
	productId: {
		type: 'number',
		default: 0,
	},
};

export default blockAttributes;
