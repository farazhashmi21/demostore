/**
 * Grouped Product Add To Cart Form
 */
const Grouped = () => (
	<p>This is a placeholder for the grouped products form element.</p>
);

export default Grouped;
