export interface Attributes {
	className?: string;
}
