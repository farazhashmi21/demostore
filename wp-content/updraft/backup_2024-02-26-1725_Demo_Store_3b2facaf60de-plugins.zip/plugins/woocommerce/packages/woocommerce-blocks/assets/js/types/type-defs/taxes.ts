export type TaxRate = {
	country: string;
	rate: string;
	name: string;
	shipping: boolean;
	priority: number;
};
