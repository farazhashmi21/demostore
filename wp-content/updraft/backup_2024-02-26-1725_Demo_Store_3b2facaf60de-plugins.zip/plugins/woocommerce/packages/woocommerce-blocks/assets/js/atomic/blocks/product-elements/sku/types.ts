export interface Attributes {
	productId: number;
	isDescendentOfQueryLoop: boolean;
	isDescendentOfSingleProductTemplate: boolean;
	showProductSelector: boolean;
	isDescendantOfAllProducts: boolean;
}
